# GamesPlayOnWeb
Play games on web browser. 

view the demo:https://geekgallifrey.github.io/GamesPlayOnWeb/

ruffle.js with flash games: demo game --- PACMAN. Play on PC only!!


jsdos with jsdos games:demo game --- DIGGER. patience, need time to loading……
It could play on the Phone and PC!!!!
Use emulator keyborads to play the game on the phone!!!
Use your computer keyboard to play the game or use vitural keyboards .
